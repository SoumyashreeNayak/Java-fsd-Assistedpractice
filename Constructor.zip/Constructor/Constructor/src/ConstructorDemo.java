public class ConstructorDemo {

    // Default (no-argument) constructor
    public ConstructorDemo() {
        System.out.println("Default Constructor");
    }

    // Parameterized constructor
    public ConstructorDemo(String message) {
        System.out.println("Parameterized Constructor: " + message);
    }

    // Copy constructor
    public ConstructorDemo(ConstructorDemo other) {
        System.out.println("Copy Constructor");
        // Perform copying logic if needed
    }

    public static void main(String[] args) {
        // Creating objects using different constructors

        // Creating an object using the default constructor
        ConstructorDemo defaultConstructorObj = new ConstructorDemo();

        // Creating an object using the parameterized constructor
        ConstructorDemo parameterizedConstructorObj = new ConstructorDemo("Hello, World!");

        // Creating an object using the copy constructor
        ConstructorDemo originalObj = new ConstructorDemo("Original Object");
        ConstructorDemo copyConstructorObj = new ConstructorDemo(originalObj);

        // Note: The copy constructor doesn't perform a deep copy in this example; you may modify it based on your needs.
    }
}
