import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {

    public static void main(String[] args) {
        // Example 1: Matching a pattern in a string
        String text1 = "The quick brown fox jumps over the lazy dog.";
        String pattern1 = "fox";

        Pattern patternObject1 = Pattern.compile(pattern1);
        Matcher matcher1 = patternObject1.matcher(text1);

        System.out.println("Example 1 - Matching a pattern in a string:");
        while (matcher1.find()) {
            System.out.println("Found at index " + matcher1.start() + " - " + matcher1.group());
        }

        // Example 2: Matching numbers in a string
        String text2 = "The price of the product is $25.99";
        String pattern2 = "\\$\\d+\\.\\d{2}";

        Pattern patternObject2 = Pattern.compile(pattern2);
        Matcher matcher2 = patternObject2.matcher(text2);

        System.out.println("\nExample 2 - Matching numbers in a string:");
        while (matcher2.find()) {
            System.out.println("Found at index " + matcher2.start() + " - " + matcher2.group());
        }

        // Example 3: Splitting a string using a regular expression
        String text3 = "Java,C++,Python,JavaScript";
        String pattern3 = ",";

        String[] languages = text3.split(pattern3);

        System.out.println("\nExample 3 - Splitting a string using a regular expression:");
        for (String language : languages) {
            System.out.println(language);
        }
    }
}
