import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {

    public static void main(String[] args) {
        // Creating a HashMap
        Map<String, Integer> hashMap = new HashMap<>();

        // Adding key-value pairs to the HashMap
        hashMap.put("Java", 20);
        hashMap.put("Python", 15);
        hashMap.put("C++", 10);

        // Accessing elements using keySet
        Set<String> keys = hashMap.keySet();
        System.out.println("HashMap elements:");

        for (String key : keys) {
            System.out.println("Key: " + key + ", Value: " + hashMap.get(key));
        }

        // Other Map operations
        System.out.println("\nOther Map Operations:");
        System.out.println("Size of HashMap: " + hashMap.size());
        System.out.println("Is HashMap empty? " + hashMap.isEmpty());

        // Updating a value associated with a key
        hashMap.put("Java", hashMap.get("Java") + 5);
        System.out.println("Updated value for key 'Java': " + hashMap.get("Java"));

        // Removing a key-value pair
        hashMap.remove("C++");
        System.out.println("After removing key 'C++':");
        for (String key : keys) {
            System.out.println("Key: " + key + ", Value: " + hashMap.get(key));
        }

        // Check if a key exists in the HashMap
        boolean containsKey = hashMap.containsKey("Python");
        System.out.println("HashMap contains key 'Python': " + containsKey);

        // Check if a value exists in the HashMap
        boolean containsValue = hashMap.containsValue(15);
        System.out.println("HashMap contains value 15: " + containsValue);
    }
}

