import java.util.Scanner;
// Custom exception class
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionsDemo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Enter a number greater than 100:");
            int userInput = scanner.nextInt();

            // Using 'throw' to manually throw an exception
            if (userInput <= 100) {
                throw new CustomException("Number should be greater than 100");
            }

            // Using 'throws' to declare the exception in the method signature
            processNumber(userInput);

        } catch (CustomException e) {
           
            System.out.println("Custom Exception: " + e.getMessage());
        } catch (Exception e) {
           
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            // The 'finally' block is used to clean up resources
            System.out.println("Finally block executed. Closing resources.");
            scanner.close();
        }
    }

    // Method that declares a custom exception using 'throws'
    private static void processNumber(int number) throws CustomException {
        System.out.println("Processing number: " + number);

      
        if (number % 2 == 0) {
            System.out.println("Number is even.");
        } else {
            System.out.println("Number is odd.");
        }

       
        if (number > 200) {
            throw new CustomException("Number is too large");
        }
    }
}
