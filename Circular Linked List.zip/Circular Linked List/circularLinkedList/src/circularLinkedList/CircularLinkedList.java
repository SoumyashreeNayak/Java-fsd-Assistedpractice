package circularLinkedList;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    private Node head;

    public SortedCircularLinkedList() {
        this.head = null;
    }

    
    public void insert(int newData) {
        Node newNode = new Node(newData);

        
        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (newData < head.data) {
            
            Node last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = head;
        } else {
            
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }

            newNode.next = current.next;
            current.next = newNode;
        }
    }

    
    public void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    
    private Node getLastNode() {
        Node last = head;
        while (last.next != head) {
            last = last.next;
        }
        return last;
    }
}

public class CircularLinkedList {
    public static void main(String[] args) {
        SortedCircularLinkedList circularList = new SortedCircularLinkedList();

        circularList.insert(20);
        circularList.insert(30);
        circularList.insert(40);
        circularList.insert(10);

        System.out.println("Sorted Circular Linked List:");
        circularList.display();
    }
}

