public class MethodDemo {

    public void printHello() {
        System.out.println("Hello, World!");
    }

    
    public void greetPerson(String name) {
        System.out.println("Hello, " + name + "!");
    }

    
    public int addNumbers(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        MethodDemo demo = new MethodDemo();
        demo.printHello();
        
        demo.greetPerson("John");

        int result = demo.addNumbers(5, 7);
        System.out.println("Result of adding numbers: " + result);

        int x = 10;
        int y = 20;
        int sum = demo.addNumbers(x, y);
        System.out.println("Result of adding numbers: " + sum);
    }
}
