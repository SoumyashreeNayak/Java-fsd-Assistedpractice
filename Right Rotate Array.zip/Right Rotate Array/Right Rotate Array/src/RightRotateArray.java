public class RightRotateArray {

    public static void main(String[] args) {
        int[] originalArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        
        int steps = 5;

        System.out.println("Original Array:");
        printArray(originalArray);

        int[] rotatedArray = rightRotate(originalArray, steps);

        System.out.println("\nArray after Right Rotation by " + steps + " steps:");
        printArray(rotatedArray);
    }

    
    private static int[] rightRotate(int[] arr, int steps) {
        int n = arr.length;
        int[] rotatedArray = new int[n];

        steps = steps % n;

        for (int i = 0; i < n; i++) {
            rotatedArray[(i + steps) % n] = arr[i];
        }

        return rotatedArray;
    }

    
    private static void printArray(int[] arr) {
        for (int value : arr) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}
