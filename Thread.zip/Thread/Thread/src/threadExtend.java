
class AThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread " + Thread.currentThread().getId() + " - Count: " + i);
        }
    }
}

class BRunnable implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread " + Thread.currentThread().getId() + " - Count: " + i);
        }
    }
}

public class threadExtend {

	public static void main(String[] args) {
		
		 AThread thread1 = new AThread();
	        thread1.start();

	        Thread thread2 = new Thread(new BRunnable());
	        thread2.start();
	    
	
	

	}

}