public class Arrays {

    public static void main(String[] args) {
        int[] intArray = {1, 2, 3, 4, 5};

       
        System.out.println("Integer Array Elements:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.print(intArray[i] + " ");
        }
        System.out.println(); 
        String[] stringArray = {"Java", "Python", "C++", "JavaScript"};

        
        System.out.println("\nString Array Elements:");
        for (String language : stringArray) {
            System.out.print(language + " ");
        }
        System.out.println(); 

        int[][] twoDArray = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

       
        System.out.println("\n2D Array Elements:");
        for (int row = 0; row < twoDArray.length; row++) {
            for (int col = 0; col < twoDArray[row].length; col++) {
                System.out.print(twoDArray[row][col] + " ");
            }
            System.out.println(); 
        }
    }
}
