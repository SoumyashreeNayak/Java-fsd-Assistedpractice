package stack;

class Stack {
    private static final int MAX_SIZE = 10;
    private int top;
    private int[] array;

    public Stack() {
        this.top = -1;
        this.array = new int[MAX_SIZE];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == MAX_SIZE - 1;
    }

    public void push(int element) {
        if (isFull()) {
            System.out.println("Stack Overflow: Cannot push element " + element + ", the stack is full.");
        } else {
            array[++top] = element;
            System.out.println("Pushed: " + element);
        }
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow: Cannot pop element, the stack is empty.");
            return -1; 
        } else {
            int poppedElement = array[top--];
            System.out.println("Popped: " + poppedElement);
            return poppedElement;
        }
    }

    public void display() {
        System.out.print("Stack elements: ");
        for (int i = 0; i <= top; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
}

public class StackExample {
    public static void main(String[] args) {
        Stack stack = new Stack();

        
        System.out.println("Pushing elements onto the stack:");
        for (int i = 1; i <= 5; i++) {
            stack.push(i * 10);
        }
        stack.display();

        
        System.out.println("\nPopping elements from the stack:");
        for (int i = 1; i <= 3; i++) {
            stack.pop();
        }
        stack.display();
    }
}
