import java.util.Arrays;

public class FourthSmallestElement {

    public static void main(String[] args) {
       int[] unsortedList = {12, 5, 9, 17, 4, 8, 21, 15};

       int fourthSmallest = findFourthSmallest(unsortedList);

       System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    
    private static int findFourthSmallest(int[] arr) {
        
        Arrays.sort(arr);
        if (arr.length >= 4) {
            return arr[3]; 
        } else {
           
            System.out.println("The array has less than four elements.");
            return -1; 
        }
    }
}
