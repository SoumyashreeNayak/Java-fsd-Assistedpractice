public class TypeCasting {
    public static void main(String[] args) {
      
        int intValue = 100;
        long longValue = intValue; 

        float floatValue = longValue; 
        double doubleValue = floatValue; 

        System.out.println("Implicit Casting:");
        System.out.println("int to long: " + longValue);
        System.out.println("long to float: " + floatValue);
        System.out.println("float to double: " + doubleValue);

        
        double anotherDoubleValue = 123.456;
        float anotherFloatValue = (float) anotherDoubleValue; 
        long anotherLongValue = (long) anotherFloatValue; 
        int anotherIntValue = (int) anotherLongValue; 

        System.out.println("\nExplicit Casting:");
        System.out.println("double to float: " + anotherFloatValue);
        System.out.println("float to long: " + anotherLongValue);
        System.out.println("long to int: " + anotherIntValue);
    }
}
