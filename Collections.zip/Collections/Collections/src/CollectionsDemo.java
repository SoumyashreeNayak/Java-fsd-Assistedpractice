import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CollectionsDemo {

    public static void main(String[] args) {
        // ArrayList Example
        ArrayList<String> arrayList = new ArrayList<>();

        // Adding elements to the ArrayList
        arrayList.add("Java");
        arrayList.add("Python");
        arrayList.add("C++");

        // Accessing elements using for-each loop
        System.out.println("ArrayList elements:");
        for (String language : arrayList) {
            System.out.println(language);
        }

        // HashMap Example
        HashMap<Integer, String> hashMap = new HashMap<>();

        // Adding key-value pairs to the HashMap
        hashMap.put(1, "Apple");
        hashMap.put(2, "Banana");
        hashMap.put(3, "Orange");

        // Accessing elements using Iterator
        System.out.println("\nHashMap elements:");
        Iterator<Map.Entry<Integer, String>> iterator = hashMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, String> entry = iterator.next();
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Other Collection operations
        System.out.println("\nOther Collection Operations:");
        System.out.println("ArrayList size: " + arrayList.size());
        System.out.println("HashMap size: " + hashMap.size());

        // Check if an element exists in ArrayList
        boolean containsJava = arrayList.contains("Java");
        System.out.println("ArrayList contains 'Java': " + containsJava);

        // Remove an element from ArrayList
        arrayList.remove("Java");
        System.out.println("After removing 'Java' from ArrayList:");
        for (String language : arrayList) {
            System.out.println(language);
        }

        // Check if a key exists in HashMap
        boolean containsKey = hashMap.containsKey(2);
        System.out.println("HashMap contains key 2: " + containsKey);
    }
}
