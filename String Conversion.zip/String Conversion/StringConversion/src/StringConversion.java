public class StringConversion {
    public static void main(String[] args) {
        // Creating a String
        String originalString = "Hello, World!";

        // Displaying the original String
        System.out.println("Original String: " + originalString);

        // Converting String to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);

        // Displaying the StringBuffer
        System.out.println("Converted to StringBuffer: " + stringBuffer);

        // Converting String to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);

        // Displaying the StringBuilder
        System.out.println("Converted to StringBuilder: " + stringBuilder);
    }
}
