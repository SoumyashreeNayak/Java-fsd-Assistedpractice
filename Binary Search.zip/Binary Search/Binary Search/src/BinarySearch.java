public class BinarySearch {

    
    public static int binarySearch(int[] array, int target) {
        int low = 0;
        int high = array.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;

            if (array[mid] == target) {
                return mid; 
            } else if (array[mid] < target) {
                low = mid + 1; 
            } else {
                high = mid - 1; 
            }
        }

        return -1; 
    }

    public static void main(String[] args) {
        
        int[] data = {2, 5, 8, 12, 16, 23, 38, 45, 56, 72};
        int targetValue = 23;
        int index = binarySearch(data, targetValue);

        
        if (index != -1) {
            System.out.println("Element " + targetValue + " found at index " + index);
        } else {
            System.out.println("Element " + targetValue + " not found in the array");
        }
    }
}

