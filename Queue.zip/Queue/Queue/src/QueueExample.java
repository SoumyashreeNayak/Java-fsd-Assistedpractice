class Queue {
    private static final int MAX_SIZE = 10;
    private int front, rear, size;
    private int[] array;

    public Queue() {
        this.front = 0;
        this.rear = -1;
        this.size = 0;
        this.array = new int[MAX_SIZE];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == MAX_SIZE;
    }

    public void enqueue(int element) {
        if (isFull()) {
            System.out.println("Queue Overflow: Cannot enqueue element " + element + ", the queue is full.");
        } else {
            rear = (rear + 1) % MAX_SIZE;
            array[rear] = element;
            size++;
            System.out.println("Enqueued: " + element);
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow: Cannot dequeue element, the queue is empty.");
            return -1; // Indicate an error
        } else {
            int dequeuedElement = array[front];
            front = (front + 1) % MAX_SIZE;
            size--;
            System.out.println("Dequeued: " + dequeuedElement);
            return dequeuedElement;
        }
    }

    public void display() {
        System.out.print("Queue elements: ");
        int count = 0;
        int index = front;
        while (count < size) {
            System.out.print(array[index] + " ");
            index = (index + 1) % MAX_SIZE;
            count++;
        }
        System.out.println();
    }
}

public class QueueExample {
    public static void main(String[] args) {
        Queue queue = new Queue();

        // Enqueue elements into the queue
        System.out.println("Enqueuing elements into the queue:");
        for (int i = 1; i <= 5; i++) {
            queue.enqueue(i * 10);
        }
        queue.display();

        // Dequeue elements from the queue
        System.out.println("\nDequeuing elements from the queue:");
        for (int i = 1; i <= 3; i++) {
            queue.dequeue();
        }
        queue.display();
    }
}
