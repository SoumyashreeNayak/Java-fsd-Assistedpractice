public class AccessModifiers {
 // Public field
 public int publicField = 10;

 // Protected field
 protected int protectedField = 20;

 // Default (package-private) field
 int defaultField = 30;

 // Private field
 private int privateField = 40;

 // Public constructor
 public AccessModifiers() {
     System.out.println("Public constructor");
 }

 // Protected method
 protected void protectedMethod() {
     System.out.println("Protected method");
 }

 // Default (package-private) method
 void defaultMethod() {
     System.out.println("Default method");
 }

 // Private method
 private void privateMethod() {
     System.out.println("Private method");
 }

 // Main method to demonstrate access modifiers
 public static void main(String[] args) {
     AccessModifiers example = new AccessModifiers();

     System.out.println("Accessing fields:");
     System.out.println("Public field: " + example.publicField);
     System.out.println("Protected field: " + example.protectedField);
     System.out.println("Default field: " + example.defaultField);
     System.out.println("Private field: " + example.privateField);

     System.out.println("\nAccessing methods:");
     example.protectedMethod();
     example.defaultMethod();
     example.privateMethod();
 }
}
