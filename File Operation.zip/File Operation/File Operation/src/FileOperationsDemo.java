import java.nio.file.*;
import java.io.IOException;
import java.util.List;

public class FileOperationsDemo {

    public static void main(String[] args) {
        
        String filePath = "sample.txt";

        createFile(filePath);

       
        String content = readFromFile(filePath);
        System.out.println("File content: " + content);

        
        updateFile(filePath, "Updated content.");

        
        content = readFromFile(filePath);
        System.out.println("Updated content: " + content);

        deleteFile(filePath);
    }

    // Create a file
    private static void createFile(String filePath) {
        try {
            Files.createFile(Paths.get(filePath));
            System.out.println("File created successfully.");
        } catch (IOException e) {
            System.err.println("Error creating file: " + e.getMessage());
        }
    }


    // Read data from a file
    private static String readFromFile(String filePath) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            StringBuilder content = new StringBuilder();
            for (String line : lines) {
                content.append(line).append("\n");
            }
            return content.toString().trim();
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
            return "";
        }
    }

    // Update data in a file
    private static void updateFile(String filePath, String newData) {
        try {
            Files.write(Paths.get(filePath), newData.getBytes(), StandardOpenOption.WRITE);
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.err.println("Error updating file: " + e.getMessage());
        }
    }

    // Delete a file
    private static void deleteFile(String filePath) {
        try {
            Files.delete(Paths.get(filePath));
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            System.err.println("Error deleting file: " + e.getMessage());
        }
    }
}

