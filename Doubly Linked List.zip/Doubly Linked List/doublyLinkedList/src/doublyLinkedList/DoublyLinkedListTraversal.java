package doublyLinkedList;

class Node {
    int data;
    Node prev;
    Node next;

    public Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    private Node head;

    public DoublyLinkedList() {
        this.head = null;
    }

    
    public void insert(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            head = newNode;
        } else {
            Node last = getLastNode();
            last.next = newNode;
            newNode.prev = last;
        }
    }

    
    public void traverseForward() {
        System.out.println("Doubly Linked List (Forward):");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    
    public void traverseBackward() {
        System.out.println("Doubly Linked List (Backward):");
        Node last = getLastNode();
        while (last != null) {
            System.out.print(last.data + " ");
            last = last.prev;
        }
        System.out.println();
    }

    
    private Node getLastNode() {
        Node last = head;
        while (last != null && last.next != null) {
            last = last.next;
        }
        return last;
    }
}

public class DoublyLinkedListTraversal {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        
        doublyList.insert(10);
        doublyList.insert(20);
        doublyList.insert(30);
        doublyList.insert(40);

        
        doublyList.traverseForward();

        
        doublyList.traverseBackward();
    }
}

