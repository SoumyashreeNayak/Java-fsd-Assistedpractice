// Outer class
public class OuterClass {

    // Member variable in the outer class
    private int outerVariable = 10;

    // Member inner class
    public class MemberInnerClass {
        // Member variable in the inner class
        private int innerVariable = 5;

        // Member inner class method
        public void display() {
            System.out.println("Member Inner Class Display Method");
            System.out.println("Outer Variable: " + outerVariable);
            System.out.println("Inner Variable: " + innerVariable);
        }
    }

    // Method with local inner class
    public void localInnerClassMethod() {
        // Local inner class
        class LocalInnerClass {
            // Local inner class method
            public void display() {
                System.out.println("Local Inner Class Display Method");
                // Accessing outer class member variable
                System.out.println("Outer Variable: " + outerVariable);
            }
        }

        // Creating an instance of the local inner class
        LocalInnerClass localInner = new LocalInnerClass();
        localInner.display();
    }

    // Main method
    public static void main(String[] args) {
        // Creating an instance of the outer class
        OuterClass outerObj = new OuterClass();

        // Creating an instance of the member inner class
        OuterClass.MemberInnerClass memberInnerObj = outerObj.new MemberInnerClass();
        memberInnerObj.display();

        // Calling the method with a local inner class
        outerObj.localInnerClassMethod();
    }
}
