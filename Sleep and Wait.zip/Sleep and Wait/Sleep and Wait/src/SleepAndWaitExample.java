public class SleepAndWaitExample {
    public static void main(String[] args) {
    	
        System.out.println("Sleep Example:");
        sleepExample();

       
        System.out.println("\nWait and Notify Example:");
        waitAndNotifyExample();
    }

    
    private static void sleepExample() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Iteration " + i);
            try {
               
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    
    private static void waitAndNotifyExample() {
        final Object lock = new Object();

        
        Thread waitingThread = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Thread 1: Waiting for notification...");
                try {
                    lock.wait(); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Thread 1: Received notification!");
            }
        });

        
        Thread notifyingThread = new Thread(() -> {
            try {
                
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            synchronized (lock) {
                System.out.println("Thread 2: Notifying waitingThread");
                lock.notify(); 
            }
        });

       
        waitingThread.start();
        notifyingThread.start();
    }
}
